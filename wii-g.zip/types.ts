
export enum AppScreen {
  SAFETY = 'SAFETY',
  MENU = 'MENU',
  CHANNEL_PREVIEW = 'CHANNEL_PREVIEW',
  APP_RUNNING = 'APP_RUNNING',
  SYSTEM_ERROR = 'SYSTEM_ERROR',
  FORMATTING = 'FORMATTING'
}

export enum ChannelType {
  DISC = 'DISC',
  MII = 'MII',
  PHOTO = 'PHOTO',
  SHOP = 'SHOP',
  WEATHER = 'WEATHER',
  NEWS = 'NEWS',
  EMPTY = 'EMPTY',
  GEMINI = 'GEMINI',
  GAME = 'GAME',
  COOP = 'COOP',
  HOMEBREW = 'HOMEBREW',
  SETTINGS = 'SETTINGS'
}

export type GameEngineType = 'PLATFORMER' | 'RACER' | 'SHOOTER' | 'CLICKER' | 'ARENA' | 'SPORTS' | 'EMULATOR';

export interface ChannelData {
  id: string;
  type: ChannelType;
  title: string;
  icon?: React.ReactNode;
  color?: string;
  gameData?: DownloadableGame;
}

export interface DownloadableGame {
  id: string;
  title: string;
  description: string;
  sizeGB: number;
  iconName: string; 
  color: string;
  engine: GameEngineType;
}

export interface WeatherData {
  location: string;
  temp: number;
  condition: string;
  forecast: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface NewsItem {
  headline: string;
  location: string;
  snippet: string;
}

export interface Mii {
  id: string;
  name: string;
  gender: 'Male' | 'Female' | 'Other';
  favColor: string;
  imageUrl: string; // Base64 or URL
  format: 'PNG' | 'JPG';
  createdAt: number;
}

export interface Message {
  id: string;
  sender: string;
  subject: string;
  body: string;
  date: string;
  read: boolean;
  isSystem?: boolean;
}

export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  url: string;
  duration: string;
  author: string;
}
