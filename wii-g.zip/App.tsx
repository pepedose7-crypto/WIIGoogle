
import React, { useState, useEffect } from 'react';
import { 
  Tv, CloudSun, Newspaper, ShoppingBag, 
  Image as ImageIcon, User, Disc, MessageSquare, 
  Mail, ChevronLeft, ChevronRight,
  Hammer, Sword, Gamepad2, Settings, X, Gamepad, FileCode, Users, Globe
} from 'lucide-react';
import { AppScreen, ChannelType, ChannelData, DownloadableGame, Mii, Message } from './types';
import { audioService } from './services/audioService';
import Cursor from './components/Cursor';
import { GeminiApp, WeatherApp, MiiApp, ShopApp, PlayableGame, DiscApp, NewsApp, PhotoApp, CoopApp, WiiSportsApp, ZeldaApp, HomebrewApp, SettingsApp } from './components/Apps';

const IconMap: Record<string, React.ReactNode> = {
  Hammer: <Hammer size={48} />,
  Sword: <Sword size={48} />,
};

const INITIAL_CHANNELS_P1: ChannelData[] = [
  { id: 'disc', type: ChannelType.DISC, title: 'Disc Channel', icon: <Disc size={64} />, color: 'bg-white' },
  { id: 'mii', type: ChannelType.MII, title: 'Mii Channel', icon: <User size={64} />, color: 'bg-white' },
  { id: 'photo', type: ChannelType.PHOTO, title: 'Photo Channel', icon: <ImageIcon size={64} />, color: 'bg-white' },
  { id: 'shop', type: ChannelType.SHOP, title: 'Wii Shop', icon: <ShoppingBag size={64} />, color: 'bg-white' },
  { id: 'weather', type: ChannelType.WEATHER, title: 'Forecast', icon: <CloudSun size={64} />, color: 'bg-white' },
  { id: 'news', type: ChannelType.NEWS, title: 'News', icon: <Newspaper size={64} />, color: 'bg-white' },
  { id: 'gemini', type: ChannelType.GEMINI, title: 'Wii G', icon: <MessageSquare size={64} />, color: 'bg-white' },
  { id: 'coop', type: ChannelType.COOP, title: 'Co-op', icon: <Gamepad2 size={64} />, color: 'bg-white' },
  { id: 'homebrew', type: ChannelType.HOMEBREW, title: 'Homebrew', icon: <Globe size={64} />, color: 'bg-white' },
  { id: 'settings', type: ChannelType.SETTINGS, title: 'Settings', icon: <Settings size={64} />, color: 'bg-white' },
  { id: 'empty4', type: ChannelType.EMPTY, title: '', color: 'bg-white/10' },
  { id: 'empty5', type: ChannelType.EMPTY, title: '', color: 'bg-white/10' },
];

const INITIAL_CHANNELS_P2: ChannelData[] = Array(12).fill(null).map((_, i) => ({
  id: `empty_p2_${i}`,
  type: ChannelType.EMPTY,
  title: '',
  color: 'bg-white/10'
}));

// ... (Screens: Safety, Error, Formatting - Kept as is)
const SafetyScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'a' || e.key === 'Enter' || e.key === ' ') onComplete(); };
    window.addEventListener('keydown', handleKey); return () => window.removeEventListener('keydown', handleKey);
  }, [onComplete]);
  return (<div className="w-full h-full bg-black flex flex-col items-center justify-center text-center p-8 cursor-pointer" onClick={onComplete}><div className="max-w-3xl bg-[#111] border border-[#333] p-16 rounded-sm text-gray-400 font-sans tracking-wide space-y-12 shadow-2xl"><h1 className="text-4xl font-bold text-gray-200 mb-8 tracking-wider">Health and Safety</h1><p className="text-xl leading-loose font-medium">Before playing, read the <span className="text-gray-200 font-bold underline decoration-1 underline-offset-4">Operations Manual</span> for important health and safety information.</p><div className="mt-16 text-3xl text-gray-200 font-normal opacity-80 animate-pulse font-serif">Press A to continue</div></div></div>);
};

const SystemErrorScreen: React.FC<{ onFormat: () => void }> = ({ onFormat }) => {
  useEffect(() => { const handleKey = (e: KeyboardEvent) => { if (e.key.toLowerCase() === 'a' || e.key.toLowerCase() === 't') onFormat(); }; window.addEventListener('keydown', handleKey); return () => window.removeEventListener('keydown', handleKey); }, [onFormat]);
  return (<div className="w-full h-full bg-black text-white font-mono flex flex-col items-center justify-center p-12 text-center select-none cursor-none"><div className="max-w-3xl border-4 border-white p-12 bg-black"><p className="mb-8 text-lg">The system files are corrupted.</p><p className="mb-12 text-lg">Please refer to the Wii G Operations Manual for details.</p></div></div>);
};

const FormatScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  useEffect(() => { let p = 0; const interval = setInterval(() => { p += 0.4; setProgress(p); if (p >= 100) { clearInterval(interval); setTimeout(onComplete, 1500); } }, 50); return () => clearInterval(interval); }, [onComplete]);
  return (<div className="w-full h-full bg-[#eee] flex flex-col items-center justify-center text-gray-700 font-sans"><h2 className="text-2xl font-bold mb-8">System Format</h2><div className="w-[60%] h-8 bg-gray-300 rounded-full overflow-hidden border-2 border-gray-400 inner-shadow"><div className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)] transition-all duration-75" style={{ width: `${progress}%` }}></div></div><p className="mt-6 text-lg font-medium text-gray-500">Do not turn off the power.</p></div>)
}

const ChannelItem: React.FC<{ channel: ChannelData; onClick: (c: ChannelData) => void; }> = ({ channel, onClick }) => {
  const isInteractive = channel.type !== ChannelType.EMPTY;
  const renderIcon = () => { if (channel.gameData) { return IconMap[channel.gameData.iconName] || <Tv size={64} />; } return channel.icon; }
  let bgClass = "bg-white"; 
  let iconColor = "text-gray-500";
  if (channel.type === ChannelType.SHOP) { iconColor = "text-blue-400"; }
  if (channel.type === ChannelType.MII) { iconColor = "text-green-500"; }
  if (channel.type === ChannelType.PHOTO) { iconColor = "text-blue-300"; }
  if (channel.type === ChannelType.WEATHER) { iconColor = "text-blue-400"; }
  if (channel.type === ChannelType.NEWS) { iconColor = "text-green-600"; }
  if (channel.type === ChannelType.GAME) { iconColor = "text-gray-800"; }
  if (channel.type === ChannelType.COOP) { iconColor = "text-pink-500"; }
  if (channel.type === ChannelType.HOMEBREW) { iconColor = "text-blue-600"; }
  if (channel.type === ChannelType.SETTINGS) { iconColor = "text-gray-600"; }

  return (
    <div className={`relative w-full aspect-[4/3] rounded-[2rem] transition-all duration-150 group ${isInteractive ? 'cursor-none bg-white shadow-[0_4px_6px_-1px_rgba(0,0,0,0.1),inset_0_-4px_4px_rgba(0,0,0,0.1)]' : 'bg-[#ffffffaa] opacity-40 shadow-none'}`} onMouseEnter={() => isInteractive && audioService.playHoverSound()} onClick={() => { if (isInteractive) { audioService.playClickSound(); onClick(channel); } }}>
      <div className="absolute inset-0 rounded-[2rem] bg-gradient-to-b from-white/80 to-transparent opacity-80 pointer-events-none z-10"></div>
      {isInteractive && (<div className="absolute -inset-1 rounded-[2.2rem] border-[6px] border-blue-400/0 group-hover:border-blue-400/60 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.6)] transition-all duration-300 z-20"></div>)}
      <div className={`w-full h-full flex flex-col items-center justify-center p-4 relative z-0`}>{channel.type === ChannelType.DISC ? (<div className="flex flex-col items-center justify-center"><div className="animate-[spin_4s_linear_infinite] text-gray-300 opacity-50 absolute scale-150"><Disc size={80}/></div><div className="text-gray-500 font-bold text-xl relative z-10 drop-shadow-sm">Disc Channel</div></div>) : (<><div className={`${iconColor} transform group-hover:scale-110 transition-transform duration-300 drop-shadow-sm`}>{renderIcon()}</div>{channel.title && channel.type !== ChannelType.EMPTY && (<span className="mt-2 text-xs font-bold text-gray-400 uppercase tracking-widest text-center truncate w-full px-1">{channel.title}</span>)}</>)}</div>
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')] rounded-[2rem]"></div>
    </div>
  );
};

const ChannelPreview: React.FC<{ channel: ChannelData; onStart: () => void; onBack: () => void; }> = ({ channel, onStart, onBack }) => {
  const renderIcon = () => { if (channel.gameData) { return IconMap[channel.gameData.iconName] || <Tv size={96} />; } return channel.icon; }
  return (
    <div className="w-full h-full relative overflow-hidden flex flex-col bg-[#e0e0e0]">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      <div className="relative z-10 w-full p-8 flex justify-center mt-4"><div className="bg-white/90 backdrop-blur-sm border-2 border-gray-300 w-[60%] py-4 rounded-full shadow-lg text-center"><h1 className="text-3xl text-gray-600 font-bold tracking-widest uppercase drop-shadow-sm">{channel.title}</h1></div></div>
      <div className="relative z-10 flex-1 flex items-center justify-center gap-16">
         <div className={`w-96 h-72 bg-white rounded-[3rem] shadow-2xl border-8 border-gray-200 flex items-center justify-center relative overflow-hidden group`}>
            <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-300 opacity-50"></div>
            <div className={`transform scale-150 text-gray-500 drop-shadow-md ${channel.id === 'disc' ? 'animate-spin' : ''}`}>{renderIcon()}</div>
            <div className="absolute top-0 right-0 w-2/3 h-full bg-gradient-to-l from-white/40 to-transparent skew-x-12 pointer-events-none"></div>
         </div>
         <div className="w-64 h-32 relative cursor-none group" onClick={() => { audioService.playClickSound(); onStart(); }} onMouseEnter={() => audioService.playHoverSound()}>
            <div className="absolute inset-0 bg-white rounded-full shadow-xl border-4 border-gray-300 group-hover:border-blue-400 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] transition-all"></div>
            <div className="absolute inset-0 flex items-center justify-center"><span className="text-4xl font-black text-gray-700 tracking-widest group-hover:scale-110 transition-transform">Start</span></div>
            <div className="absolute top-2 left-4 w-56 h-12 bg-gradient-to-b from-white to-transparent opacity-80 rounded-full"></div>
         </div>
      </div>
      <div className="relative z-10 w-full p-8 flex justify-between px-20 pb-12"><button onClick={() => { audioService.playBackSound(); onBack(); }} className="bg-white border-2 border-gray-300 px-12 py-4 rounded-full shadow-md text-gray-600 font-bold text-xl hover:scale-105 hover:bg-gray-50 transition-all flex items-center gap-2" onMouseEnter={() => audioService.playHoverSound()}><ChevronLeft /> Wii Menu</button></div>
    </div>
  );
};

const BottomBar: React.FC<{ hasUnread: boolean, onOpenMail: () => void }> = ({ hasUnread, onOpenMail }) => {
  const [time, setTime] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(t); }, []);
  return (
    <div className="h-24 w-full bg-[#cdcdcd] border-t-4 border-white flex items-center justify-between px-12 shadow-[inset_0_2px_15px_rgba(0,0,0,0.1)] relative z-20">
      <div className="w-20 h-20 rounded-full bg-[#f0f0f0] border-4 border-gray-400 flex items-center justify-center shadow-lg text-gray-500 hover:scale-105 hover:border-blue-300 hover:text-blue-400 transition-all cursor-none group" onMouseEnter={() => audioService.playHoverSound()}><span className="font-bold text-xl tracking-tighter group-hover:drop-shadow-md">Wii</span></div>
      <div className="flex flex-col items-center"><div className="text-gray-600 font-bold text-4xl tracking-widest drop-shadow-sm font-sans">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div><div className="text-gray-500 text-lg font-bold uppercase tracking-widest mt-1">{time.toLocaleDateString([], { weekday: 'short', month: 'numeric', day: 'numeric' })}</div></div>
      <div className={`w-24 h-16 rounded-xl bg-[#f0f0f0] border-4 flex items-center justify-center text-gray-400 shadow-md hover:scale-105 hover:text-blue-400 transition-all cursor-none relative ${hasUnread ? 'border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.8)]' : 'border-gray-400'}`} onMouseEnter={() => audioService.playHoverSound()} onClick={onOpenMail}><Mail size={32} className={hasUnread ? 'text-blue-500' : ''} />{hasUnread && <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full border-2 border-white animate-pulse"></div>}</div>
    </div>
  );
};

export default function App() {
  const [screen, setScreen] = useState<AppScreen>(AppScreen.SAFETY);
  const [activeChannel, setActiveChannel] = useState<ChannelData | null>(null);
  const [isAudioInit, setIsAudioInit] = useState(false);
  const [page, setPage] = useState(0); 
  const [showControllerMenu, setShowControllerMenu] = useState(false);
  const [showMailBoard, setShowMailBoard] = useState(false);
  
  // State
  const [channelsP1, setChannelsP1] = useState(INITIAL_CHANNELS_P1);
  const [channelsP2, setChannelsP2] = useState(INITIAL_CHANNELS_P2);
  const [storageUsed, setStorageUsed] = useState(0);
  const [installedGameIds, setInstalledGameIds] = useState<string[]>([]);
  const [savedMiis, setSavedMiis] = useState<Mii[]>([]);
  const [messages, setMessages] = useState<Message[]>([{ id: '1', sender: 'System', subject: 'Welcome to Wii G', body: 'Thank you for using Wii G. Enjoy the simulation!', date: new Date().toLocaleDateString(), read: false, isSystem: true }]);
  
  // Input State
  const [p1IsGamepad, setP1IsGamepad] = useState(false);

  useEffect(() => {
    const initAudio = () => { if (!isAudioInit) { audioService.init().then(() => { audioService.startHum(); setIsAudioInit(true); }); } };
    window.addEventListener('click', initAudio); return () => window.removeEventListener('click', initAudio);
  }, [isAudioInit]);

  useEffect(() => { const interval = setInterval(() => { if(Math.random() > 0.9) { const newMsg: Message = { id: Date.now().toString(), sender: 'Nintendo News', subject: 'Update Available', body: 'A new update for "Forecast Channel" is now available.', date: new Date().toLocaleDateString(), read: false }; setMessages(prev => [...prev, newMsg]); } }, 30000); return () => clearInterval(interval); }, []);

  useEffect(() => { const handleKey = (e: KeyboardEvent) => { if (e.key.toLowerCase() === 'p') { setShowControllerMenu(prev => !prev); audioService.playClickSound(); } }; window.addEventListener('keydown', handleKey); return () => window.removeEventListener('keydown', handleKey); }, []);

  const handleChannelClick = (channel: ChannelData) => { setActiveChannel(channel); setScreen(AppScreen.CHANNEL_PREVIEW); };
  const handleInstallGame = (game: DownloadableGame) => {
    let placed = false; const newP1 = [...channelsP1]; const emptyIdxP1 = newP1.findIndex(c => c.type === ChannelType.EMPTY);
    if (emptyIdxP1 !== -1) { newP1[emptyIdxP1] = { id: `game_${game.id}`, type: ChannelType.GAME, title: game.title, color: game.color, gameData: game }; setChannelsP1(newP1); placed = true; } 
    else { const newP2 = [...channelsP2]; const emptyIdxP2 = newP2.findIndex(c => c.type === ChannelType.EMPTY); if (emptyIdxP2 !== -1) { newP2[emptyIdxP2] = { id: `game_${game.id}`, type: ChannelType.GAME, title: game.title, color: game.color, gameData: game }; setChannelsP2(newP2); placed = true; } }
    if (placed) { setStorageUsed(prev => prev + game.sizeGB); setInstalledGameIds(prev => [...prev, game.id]); const msg: Message = { id: Date.now().toString(), sender: 'Nintendo', subject: 'Download Complete', body: `You have successfully downloaded ${game.title}. Check the Wii Menu to play.`, date: new Date().toLocaleDateString(), read: false }; setMessages(prev => [msg, ...prev]); } 
    else { alert("Channel Grid Full. Delete content."); }
  };

  const handleAddMii = (mii: Mii) => { setSavedMiis(prev => [...prev, mii]); };
  const handleFormat = () => { setScreen(AppScreen.FORMATTING); };
  const handleFormatComplete = () => { setChannelsP1(INITIAL_CHANNELS_P1); setChannelsP2(INITIAL_CHANNELS_P2); setStorageUsed(0); setInstalledGameIds([]); setSavedMiis([]); setMessages([]); setScreen(AppScreen.SAFETY); };

  const renderContent = () => {
    switch (screen) {
      case AppScreen.SAFETY: return <SafetyScreen onComplete={() => { audioService.playClickSound(); setScreen(AppScreen.MENU); }} />;
      case AppScreen.SYSTEM_ERROR: return <SystemErrorScreen onFormat={handleFormat} />;
      case AppScreen.FORMATTING: return <FormatScreen onComplete={handleFormatComplete} />;
      case AppScreen.MENU:
        const currentChannels = page === 0 ? channelsP1 : channelsP2;
        return (
          <div className="flex flex-col h-full w-full bg-[#eeeeee] overflow-hidden relative font-sans">
             <div className="absolute inset-0 bg-[linear-gradient(rgba(180,180,180,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(180,180,180,0.2)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
             <div className={`absolute left-0 top-1/2 -translate-y-1/2 h-24 w-12 bg-white/50 hover:bg-blue-400/20 rounded-r-2xl border-r border-t border-b border-gray-300 flex items-center justify-center cursor-pointer transition-all z-30 ${page === 0 ? 'opacity-20 pointer-events-none' : 'opacity-80 hover:scale-110'}`} onClick={() => { audioService.playHoverSound(); setPage(0); }}><ChevronLeft size={40} className="text-gray-500" /></div>
             <div className={`absolute right-0 top-1/2 -translate-y-1/2 h-24 w-12 bg-white/50 hover:bg-blue-400/20 rounded-l-2xl border-l border-t border-b border-gray-300 flex items-center justify-center cursor-pointer transition-all z-30 ${page === 1 ? 'opacity-20 pointer-events-none' : 'opacity-80 hover:scale-110'}`} onClick={() => { audioService.playHoverSound(); setPage(1); }}><ChevronRight size={40} className="text-gray-500" /></div>
             <div className="flex-1 p-16 grid grid-cols-4 grid-rows-3 gap-6 max-w-7xl mx-auto w-full z-10">{currentChannels.map((ch, idx) => (<ChannelItem key={ch.id} channel={ch} onClick={handleChannelClick} />))}</div>
             <BottomBar hasUnread={messages.some(m => !m.read)} onOpenMail={() => setShowMailBoard(true)} />
          </div>
        );
      case AppScreen.CHANNEL_PREVIEW: return activeChannel ? (<ChannelPreview channel={activeChannel} onStart={() => setScreen(AppScreen.APP_RUNNING)} onBack={() => setScreen(AppScreen.MENU)}/>) : null;
      case AppScreen.APP_RUNNING:
        if (!activeChannel) return null;
        if (activeChannel.type === ChannelType.WEATHER) return <WeatherApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.NEWS) return <NewsApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.PHOTO) return <PhotoApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.GEMINI) return <GeminiApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.MII) return <MiiApp onBack={() => setScreen(AppScreen.MENU)} savedMiis={savedMiis} onSaveMii={handleAddMii} installedGames={installedGameIds}/>;
        if (activeChannel.type === ChannelType.DISC) return <DiscApp onBack={() => setScreen(AppScreen.MENU)} systemData={{ channels: channelsP1, storage: storageUsed }} onBrickSystem={() => setScreen(AppScreen.SYSTEM_ERROR)}/>;
        if (activeChannel.type === ChannelType.SHOP) return <ShopApp onBack={() => setScreen(AppScreen.MENU)} installedGames={installedGameIds} onInstallGame={handleInstallGame} storageUsed={storageUsed}/>;
        if (activeChannel.type === ChannelType.GAME && activeChannel.gameData) return <PlayableGame onBack={() => setScreen(AppScreen.MENU)} activeGame={activeChannel.gameData} p1IsGamepad={p1IsGamepad} />;
        if (activeChannel.type === ChannelType.COOP) return <CoopApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.HOMEBREW) return <HomebrewApp onBack={() => setScreen(AppScreen.MENU)} />;
        if (activeChannel.type === ChannelType.SETTINGS) return <SettingsApp onBack={() => setScreen(AppScreen.MENU)} p1IsGamepad={p1IsGamepad} onSetP1Gamepad={setP1IsGamepad} />;
        return null;
      default: return null;
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#111] flex items-center justify-center overflow-hidden scanlines">
      <div className="relative w-full h-full bg-white shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden">
        {renderContent()}
        {showControllerMenu && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm z-50">
             <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-lg w-full border-4 border-blue-200">
                <div className="flex justify-between items-center mb-6"><h2 className="text-2xl font-black text-gray-700 flex items-center gap-2"><Settings /> Controller Settings</h2><button onClick={() => setShowControllerMenu(false)} className="text-gray-400 hover:text-red-500"><X /></button></div>
                <div className="space-y-4">
                   <div className="flex items-center justify-between bg-white border border-gray-200 p-3 rounded-lg shadow-sm"><div className="flex items-center gap-3"><div className="w-8 h-8 rounded-md bg-blue-500"></div><span className="font-bold text-gray-700">Player 1</span></div><div className="text-sm font-mono text-gray-500 bg-gray-50 px-2 py-1 rounded flex items-center gap-2"><FileCode size={14} /> {p1IsGamepad ? 'Gamepad (Leader)' : 'Mouse / Keyboard'}</div></div>
                   <div className="mt-8 text-center text-sm text-gray-400 bg-blue-50 p-6 rounded-xl border border-blue-100 space-y-2"><div className="font-bold text-lg text-blue-600">Connect more controllers</div><div>Press <span className="font-bold text-black border border-gray-300 rounded px-1">LB</span> + <span className="font-bold text-black border border-gray-300 rounded px-1">RB</span> together</div><div className="text-xs pt-2">Use Right Stick to move pointer</div></div>
                </div>
             </div>
          </div>
        )}
        {showMailBoard && (
           <div className="absolute inset-0 bg-white z-50 flex flex-col font-sans animate-in slide-in-from-bottom duration-500">
              <div className="bg-[#cdcdcd] p-4 flex justify-between items-center border-b-4 border-white shadow-md"><h1 className="text-2xl font-bold text-gray-600 tracking-wider">Wii Message Board</h1><button onClick={() => setShowMailBoard(false)} className="bg-white px-6 py-2 rounded-full font-bold text-gray-600 border border-gray-400 hover:bg-gray-100">Back</button></div>
              <div className="flex-1 bg-[url('https://www.transparenttextures.com/patterns/cork-board.png')] bg-[#f5f5f5] p-12 overflow-y-auto"><div className="max-w-4xl mx-auto space-y-6">{messages.length === 0 && <div className="text-center text-gray-400 font-bold text-2xl mt-20">No Messages Today</div>}{messages.map(msg => (<div key={msg.id} className={`bg-white p-6 rounded-xl shadow-lg border-2 ${msg.isSystem ? 'border-red-300' : 'border-blue-200'} transform hover:scale-[1.02] transition-transform`} onClick={() => { setMessages(prev => prev.map(m => m.id === msg.id ? {...m, read: true} : m)); }}><div className="flex justify-between items-start mb-4"><div><h3 className="text-xl font-bold text-gray-700">{msg.sender}</h3><p className="text-sm text-gray-400">{msg.date}</p></div>{!msg.read && <div className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">NEW</div>}</div><div className="border-t border-gray-100 pt-4"><h4 className="font-bold text-gray-800 mb-2">{msg.subject}</h4><p className="text-gray-600 leading-relaxed">{msg.body}</p></div></div>))}</div></div>
           </div>
        )}
        <Cursor p1IsGamepad={p1IsGamepad} />
      </div>
    </div>
  );
}
