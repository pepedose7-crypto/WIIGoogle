import { GoogleGenAI } from "@google/genai";
import { ChatMessage, WeatherData } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiWeather = async (): Promise<WeatherData> => {
  try {
    const ai = getAI();
    // Simulate getting location or just ask for a general fun forecast
    const prompt = `Generate a creative, slightly futuristic or fantasy weather report for "Wii City". 
    Return strictly valid JSON with keys: location, temp (number), condition (short string), forecast (one sentence).`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Weather gen error:", error);
    return {
      location: "Connection Error",
      temp: 0,
      condition: "Static",
      forecast: "Unable to reach the weather satellites."
    };
  }
};

export const streamGeminiResponse = async (
  history: ChatMessage[], 
  newMessage: string,
  onChunk: (text: string) => void
) => {
  try {
    const ai = getAI();
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: "You are the Wii G AI. You are helpful, polite, and slightly nostalgic about Nintendo history. Keep answers concise.",
      }
    });
    
    const result = await chat.sendMessageStream({ message: newMessage });
    
    for await (const chunk of result) {
      if (chunk.text) {
        onChunk(chunk.text);
      }
    }
  } catch (error) {
    console.error("Stream error:", error);
    onChunk(" [Communication Error]");
  }
};

export const generateMiiImage = async (
  name: string, 
  gender: string, 
  color: string, 
  style: string,
  contextGames: string[]
): Promise<string | null> => {
  try {
    const ai = getAI();
    const gameContext = contextGames.length > 0 ? `The user likes these games: ${contextGames.join(', ')}.` : '';
    
    const prompt = `Generate a cute 3D-style Nintendo Mii avatar. 
    Name: ${name}. Gender: ${gender}. Shirt Color: ${color}. 
    Style/Hair details: ${style}.
    ${gameContext}
    The image should be a clean, front-facing character portrait on a white background, similar to official Mii Channel art. 
    Make it look like a high-quality 3D render.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
        }
      }
    });

    // Extract image
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Mii Gen Error:", error);
    return null;
  }
};