
import React, { useState, useEffect, useRef } from 'react';
import { getGeminiWeather, streamGeminiResponse, generateMiiImage } from '../services/geminiService';
import { WeatherData, ChatMessage, DownloadableGame, ChannelData, NewsItem, Mii, ChannelType, Video } from '../types';
import { audioService } from '../services/audioService';
import { 
  Hammer, Sword, Car, Rocket, Home, 
  HandMetal, Flower, Cloud, Ban, Shield, 
  Gamepad2, Download, CheckCircle,
  FileCode, HardDrive, Image as ImageIcon,
  Globe, Sun, User, Plus, Save, ArrowLeft, Loader2,
  X, Crosshair, Zap, Heart, MessageSquare, Disc,
  Users, Gamepad, Settings, Send, RefreshCw, AlertTriangle,
  Trophy, Circle, Flag, Target, Wind, Youtube, Play, Search, Pause, SkipForward, Volume2, Beaker
} from 'lucide-react';

interface AppProps {
  onBack: () => void;
  installedGames?: string[];
  onInstallGame?: (game: DownloadableGame) => void;
  storageUsed?: number;
  activeGame?: DownloadableGame;
  systemData?: { channels: ChannelData[], storage: number };
  onBrickSystem?: () => void;
  savedMiis?: Mii[];
  onSaveMii?: (mii: Mii) => void;
  p1IsGamepad?: boolean;
  onSetP1Gamepad?: (enabled: boolean) => void;
}

// --- ICON MAP ---
const IconMap: Record<string, React.ReactNode> = {
  Hammer: <Hammer size={48} />,
  Sword: <Sword size={48} />,
  Car: <Car size={48} />,
  Rocket: <Rocket size={48} />,
  Home: <Home size={48} />,
  Fist: <HandMetal size={48} />,
  Flower: <Flower size={48} />,
  Cloud: <Cloud size={48} />,
  Banana: <Ban size={48} />, 
  Shield: <Shield size={48} />,
  Trophy: <Trophy size={48} />,
  Triangle: <div className="w-0 h-0 border-l-[24px] border-l-transparent border-b-[40px] border-b-yellow-400 border-r-[24px] border-r-transparent"></div>
};

export const SHOP_CATALOG: DownloadableGame[] = [
  { 
    id: 'g_mario', 
    title: 'Super Mario Bros.', 
    description: 'The definitive platformer experience. Now with Local Co-op! Jump, run, and save the Kingdom with friends.', 
    sizeGB: 15.5, 
    iconName: 'Hammer', 
    color: 'bg-red-600', 
    engine: 'PLATFORMER' 
  },
  { 
    id: 'g_gemini', 
    title: 'Gemini Adventure', 
    description: 'An immersive RPG Shooter powered by next-gen AI. Explore neon dungeons and battle logic errors.', 
    sizeGB: 18.2, 
    iconName: 'Sword', 
    color: 'bg-purple-600', 
    engine: 'SHOOTER' 
  },
  { 
    id: 'g_sports', 
    title: 'Wii Sports', 
    description: 'The classic sports experience. Includes Basketball and Golf. REQUIRES 2+ PLAYERS.', 
    sizeGB: 5.5, 
    iconName: 'Trophy', 
    color: 'bg-blue-400', 
    engine: 'SPORTS' 
  },
  { 
    id: 'g_zelda', 
    title: 'The Legend of Zelda', 
    description: 'Virtual Console Emulator. Revisit the classic Hyrule in this 3D-enhanced emulation.', 
    sizeGB: 1.2, 
    iconName: 'Triangle', 
    color: 'bg-green-700', 
    engine: 'EMULATOR' 
  },
];

export const ShopApp: React.FC<AppProps> = ({ onBack, installedGames = [], onInstallGame, storageUsed = 0 }) => {
  const [view, setView] = useState<'catalog' | 'details' | 'downloading' | 'success'>('catalog');
  const [selectedGame, setSelectedGame] = useState<DownloadableGame | null>(null);
  const [progress, setProgress] = useState(0);
  
  const TOTAL_STORAGE = 40;
  const available = TOTAL_STORAGE - storageUsed;

  const handleSelect = (game: DownloadableGame) => {
    setSelectedGame(game);
    setView('details');
    audioService.playClickSound();
  };

  const handleDownload = () => {
    if (!selectedGame || !onInstallGame) return;
    if (available < selectedGame.sizeGB) {
      alert("Insufficient System Memory. Delete other channels from Data Management.");
      return;
    }
    setView('downloading');
    audioService.playClickSound();
    let p = 0;
    const interval = setInterval(() => {
      p += 0.5; 
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        onInstallGame(selectedGame);
        setView('success');
        audioService.playClickSound();
      }
    }, 50);
  };

  return (
    <div className="w-full h-full bg-white flex flex-col font-sans text-gray-800 relative">
      <div className="bg-[#E6F0FA] p-4 border-b-4 border-blue-300 flex justify-between items-center shadow-md z-10">
        <div className="flex items-center gap-2">
           <div className="bg-blue-500 text-white p-2 rounded-lg"><Gamepad2 /></div>
           <h2 className="text-2xl font-bold text-blue-600 tracking-tight">Wii Shop Channel</h2>
        </div>
        <div className="flex flex-col items-end text-sm font-bold text-gray-600">
          <span>Points: <span className="text-blue-500">2000</span></span>
          <span>Storage: <span className={available < 5 ? "text-red-500" : "text-blue-500"}>{available.toFixed(1)} GB</span> / 40 GB</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-blue-50 p-12 relative flex items-center justify-center">
        {view === 'catalog' && (
          <div className="grid grid-cols-2 gap-8 w-full max-w-5xl">
            {SHOP_CATALOG.map(game => {
              const isInstalled = installedGames.includes(game.id);
              return (
                <div 
                  key={game.id}
                  onClick={() => !isInstalled && handleSelect(game)}
                  className={`bg-white border-4 rounded-3xl p-6 flex items-center gap-6 shadow-xl transition-all relative overflow-hidden group ${
                    isInstalled ? 'opacity-60 cursor-default border-gray-300 grayscale' : 'hover:scale-105 hover:border-orange-400 cursor-pointer border-blue-200'
                  }`}
                  onMouseEnter={() => !isInstalled && audioService.playHoverSound()}
                >
                   <div className={`w-24 h-24 rounded-full ${game.color} text-white flex items-center justify-center shadow-lg`}>
                     {IconMap[game.iconName]}
                   </div>
                   <div className="flex-1 z-10">
                     <h3 className="text-2xl font-black text-gray-700 leading-tight mb-1">{game.title}</h3>
                     <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-bold text-sm">{game.sizeGB} GB</span>
                     <p className="text-gray-500 text-sm mt-2 leading-tight line-clamp-2">{game.description}</p>
                   </div>
                   {isInstalled && (
                     <div className="absolute right-4 top-4">
                        <CheckCircle className="text-green-500" />
                     </div>
                   )}
                </div>
              )
            })}
          </div>
        )}
        {view === 'details' && selectedGame && (
          <div className="w-full h-full flex items-center justify-center">
             <div className="bg-white p-12 rounded-[3rem] shadow-2xl border-4 border-blue-200 max-w-3xl w-full flex flex-col gap-8">
                <div className="flex gap-8 items-center">
                   <div className={`w-40 h-40 rounded-3xl ${selectedGame.color} flex items-center justify-center shadow-inner text-white`}>
                      <div className="transform scale-150">{IconMap[selectedGame.iconName]}</div>
                   </div>
                   <div className="flex-1">
                      <h1 className="text-5xl font-black text-gray-800 mb-4">{selectedGame.title}</h1>
                      <p className="text-gray-600 text-xl leading-relaxed">{selectedGame.description}</p>
                   </div>
                </div>
                <div className="h-px bg-gray-200 w-full"></div>
                <div className="flex justify-between items-center">
                   <div className="text-sm font-bold text-gray-400">Required: {selectedGame.sizeGB} GB Free Space</div>
                   <div className="flex gap-4">
                      <button onClick={() => { setView('catalog'); audioService.playBackSound(); }} className="px-8 py-4 rounded-full border-2 border-gray-300 font-bold text-gray-500 hover:bg-gray-100 text-lg">Back</button>
                      <button onClick={handleDownload} className="px-12 py-4 rounded-full bg-orange-400 text-white font-bold text-xl shadow-lg hover:bg-orange-500 hover:scale-105 transition-all flex items-center gap-3">
                        <Download size={28} /> Download
                      </button>
                   </div>
                </div>
             </div>
          </div>
        )}
        {view === 'downloading' && (
          <div className="w-full h-full flex flex-col items-center justify-center">
             <div className="mb-8 relative">
                <div className="w-32 h-32 bg-blue-500 rounded-lg animate-bounce flex items-center justify-center text-white shadow-xl">
                  <Gamepad2 size={64}/>
                </div>
                <div className="absolute -bottom-4 w-32 h-4 bg-black/20 rounded-[100%] blur-sm animate-pulse"></div>
             </div>
             <h2 className="text-3xl font-bold text-blue-500 mb-8 animate-pulse">Downloading Content...</h2>
             <div className="w-1/2 h-16 border-4 border-blue-300 rounded-full p-2 relative overflow-hidden bg-white shadow-inner">
                <div className="h-full bg-[repeating-linear-gradient(45deg,_#60a5fa,_#60a5fa_20px,_#3b82f6_20px,_#3b82f6_40px)] animate-[pulse_2s_linear_infinite] rounded-full transition-all duration-75 relative" style={{ width: `${progress}%` }}></div>
             </div>
             <p className="mt-6 text-gray-400 font-bold text-2xl">{progress.toFixed(0)}%</p>
          </div>
        )}
        {view === 'success' && (
           <div className="w-full h-full flex flex-col items-center justify-center">
              <div className="bg-green-100 p-8 rounded-full mb-8 text-green-600 animate-bounce"><CheckCircle size={80} /></div>
              <h2 className="text-4xl font-bold text-gray-700 mb-4">Download Successful!</h2>
              <button onClick={() => { onBack(); audioService.playBackSound(); }} className="mt-12 px-12 py-4 bg-blue-500 text-white rounded-full font-bold shadow-xl hover:scale-105 transition-transform text-xl">Return to Wii Menu</button>
           </div>
        )}
      </div>
      <div className="bg-white p-3 border-t border-gray-300 flex justify-center"><button onClick={() => { onBack(); audioService.playBackSound(); }} className="text-blue-400 font-bold hover:underline">Wii Menu</button></div>
    </div>
  );
};

export const WeatherApp: React.FC<AppProps> = ({ onBack }) => {
  const [data, setData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { getGeminiWeather().then(d => { setData(d); setLoading(false); }); }, []);
  return (
    <div className="w-full h-full bg-gradient-to-b from-blue-300 to-blue-100 relative overflow-hidden flex flex-col">
       <div className="p-8 flex justify-between items-center z-10">
          <h1 className="text-4xl font-bold text-white drop-shadow-md flex items-center gap-4"><Cloud size={48}/> Forecast Channel</h1>
          <button onClick={() => { onBack(); audioService.playBackSound(); }} className="bg-white/50 hover:bg-white text-blue-800 px-6 py-2 rounded-full font-bold transition-all">Back</button>
       </div>
       <div className="flex-1 flex items-center justify-center relative">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/world-map.png')] opacity-20 bg-center bg-no-repeat bg-contain animate-pulse"></div>
          {loading ? <div className="flex flex-col items-center gap-4 text-white"><Loader2 size={64} className="animate-spin" /><span className="text-2xl font-bold">Consulting Satellites...</span></div> : (
             <div className="bg-white/80 backdrop-blur-md p-12 rounded-3xl shadow-2xl text-center max-w-2xl border-4 border-white">
                <h2 className="text-6xl font-black text-gray-700 mb-2">{data?.location}</h2>
                <div className="text-9xl font-black text-blue-500 my-8 flex items-center justify-center gap-4">{data?.temp}° <span className="text-4xl text-gray-400">F</span></div>
                <div className="text-3xl font-bold text-gray-600 mb-6 uppercase tracking-widest">{data?.condition}</div>
                <p className="text-xl text-gray-500 italic bg-blue-50 p-6 rounded-xl border border-blue-100">"{data?.forecast}"</p>
             </div>
          )}
       </div>
       <div className="bg-blue-500 h-16 w-full flex items-center justify-center text-white font-bold tracking-widest text-lg">POWERED BY GEMINI METEOROLOGY</div>
    </div>
  )
}

export const NewsApp: React.FC<AppProps> = ({ onBack }) => {
   const headlines: NewsItem[] = [
      { headline: "Local Cat Elected Mayor of Wii City", location: "Wii City", snippet: "Promises more naps and tuna for all residents." },
      { headline: "Mystery 'Switch 2' Rumors Swirl", location: "Kyoto", snippet: "Analysts predict it will be very round." },
      { headline: "Gemini AI Writes Better Code Than Humans?", location: "Mountain View", snippet: "Developers panic, then take a nap." }
   ];
   return (
      <div className="w-full h-full bg-[#e8e8e8] flex flex-col font-serif">
         <div className="bg-green-600 text-white p-4 shadow-lg flex justify-between items-center z-10">
            <h1 className="text-3xl font-bold italic tracking-tighter">NEWS CHANNEL</h1>
            <div className="text-sm font-mono">{new Date().toLocaleDateString()}</div>
         </div>
         <div className="flex-1 p-8 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/paper.png')]">
            <div className="max-w-4xl mx-auto space-y-8">
               {headlines.map((item, i) => (
                  <div key={i} className="bg-white p-6 shadow-md border-l-8 border-green-500 rotate-1 hover:rotate-0 transition-transform cursor-pointer" onMouseEnter={() => audioService.playHoverSound()}>
                     <h2 className="text-2xl font-bold text-gray-800 mb-2">{item.headline}</h2>
                     <div className="flex justify-between text-gray-500 text-sm mb-4 border-b pb-2"><span className="uppercase font-bold tracking-wide">{item.location}</span><span>AP WIRE</span></div>
                     <p className="text-lg leading-relaxed text-gray-700">{item.snippet}</p>
                  </div>
               ))}
            </div>
         </div>
         <div className="bg-gray-200 p-4 border-t border-gray-300 flex justify-center"><button onClick={() => { onBack(); audioService.playBackSound(); }} className="bg-white border border-gray-400 px-8 py-2 rounded-full font-bold text-gray-600 shadow-sm hover:bg-gray-50">Back</button></div>
      </div>
   )
}

export const PhotoApp: React.FC<AppProps> = ({ onBack }) => {
   return (
      <div className="w-full h-full bg-black flex flex-col items-center justify-center relative">
         <div className="text-white text-center">
            <ImageIcon size={120} className="mx-auto mb-8 text-gray-500" />
            <h1 className="text-4xl font-bold text-gray-300 mb-4">Photo Channel 1.1</h1>
            <p className="text-gray-500 text-xl">No SD Card Detected.</p>
         </div>
         <button onClick={() => { onBack(); audioService.playBackSound(); }} className="absolute bottom-12 bg-gray-800 text-white px-8 py-3 rounded-full font-bold hover:bg-gray-700 border border-gray-600">Return</button>
      </div>
   )
}

export const GeminiApp: React.FC<AppProps> = ({ onBack }) => {
   const [history, setHistory] = useState<ChatMessage[]>([]);
   const [input, setInput] = useState("");
   const [streaming, setStreaming] = useState(false);
   const chatEndRef = useRef<HTMLDivElement>(null);
   const handleSend = async () => {
      if (!input.trim() || streaming) return;
      const userMsg: ChatMessage = { role: 'user', text: input };
      setHistory(prev => [...prev, userMsg]);
      setInput("");
      setStreaming(true);
      let botResponse = "";
      setHistory(prev => [...prev, { role: 'model', text: '' }]);
      await streamGeminiResponse(history, input, (chunk) => {
         botResponse += chunk;
         setHistory(prev => { const newH = [...prev]; newH[newH.length - 1].text = botResponse; return newH; });
         chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      });
      setStreaming(false);
   };
   return (
      <div className="w-full h-full bg-white flex flex-col font-sans">
         <div className="bg-blue-600 text-white p-4 shadow-md flex justify-between items-center z-10">
            <div className="flex items-center gap-3"><div className="bg-white text-blue-600 p-2 rounded-full"><MessageSquare size={24}/></div><h1 className="text-2xl font-bold tracking-tight">Wii G Chat</h1></div>
            <button onClick={() => { onBack(); audioService.playBackSound(); }} className="bg-blue-700 hover:bg-blue-500 px-6 py-2 rounded-full text-sm font-bold border border-blue-400">Exit</button>
         </div>
         <div className="flex-1 bg-gray-100 p-6 overflow-y-auto space-y-6">
            {history.length === 0 && <div className="text-center text-gray-400 mt-20"><div className="bg-white p-8 rounded-full inline-block mb-4 shadow-sm"><MessageSquare size={64}/></div><h3 className="text-xl font-bold">Ask anything.</h3><p>Powered by Gemini 2.5</p></div>}
            {history.map((msg, i) => (<div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[80%] p-4 rounded-2xl shadow-sm text-lg ${msg.role === 'user' ? 'bg-blue-500 text-white rounded-br-none' : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'}`}>{msg.text}</div></div>))}
            <div ref={chatEndRef} />
         </div>
         <div className="p-4 bg-white border-t border-gray-200 flex gap-4 items-center">
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="Send a message..." className="flex-1 bg-gray-100 border-2 border-gray-300 rounded-full px-6 py-4 text-xl focus:outline-none focus:border-blue-400 transition-colors" disabled={streaming} />
            <button onClick={handleSend} disabled={streaming} className={`p-4 rounded-full bg-blue-500 text-white shadow-lg hover:bg-blue-600 hover:scale-105 transition-all ${streaming ? 'opacity-50 cursor-not-allowed' : ''}`}><Send size={24} /></button>
         </div>
      </div>
   )
}

export const MiiApp: React.FC<AppProps> = ({ onBack, savedMiis = [], onSaveMii, installedGames = [] }) => {
  const [mode, setMode] = useState<'LIST' | 'CREATE'>('LIST');
  const [form, setForm] = useState({ name: 'Mii', gender: 'Male', color: 'Red', style: 'Standard' });
  const [generating, setGenerating] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleGenerate = async () => {
     setGenerating(true);
     const context = installedGames.map(id => { if(id === 'g_mario') return 'Super Mario'; if(id === 'g_gemini') return 'Sci-Fi RPG'; return ''; }).filter(Boolean);
     const url = await generateMiiImage(form.name, form.gender, form.color, form.style, context);
     setPreviewUrl(url);
     setGenerating(false);
  };

  const handleSave = () => {
     if (previewUrl && onSaveMii) {
        onSaveMii({ id: Date.now().toString(), name: form.name, gender: form.gender as any, favColor: form.color, imageUrl: previewUrl, format: 'PNG', createdAt: Date.now() });
        setMode('LIST'); setPreviewUrl(null); audioService.playClickSound();
     }
  };

  return (
     <div className="w-full h-full bg-white flex flex-col font-sans">
        <div className="bg-[#83c6dd] p-4 flex justify-between items-center shadow-md relative z-20"><div className="flex items-center gap-2 text-white drop-shadow-md"><Users size={32} /><h1 className="text-2xl font-bold italic tracking-wider">Mii Channel</h1></div><button onClick={() => { onBack(); audioService.playBackSound(); }} className="bg-white/30 hover:bg-white/50 text-white font-bold px-6 py-2 rounded-full border border-white/50">Exit</button></div>
        {mode === 'LIST' && (
           <div className="flex-1 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-[#f0f8ff] p-12">
              <div className="max-w-6xl mx-auto"><div className="grid grid-cols-5 gap-8">
                    <div onClick={() => { setMode('CREATE'); audioService.playClickSound(); }} className="aspect-[3/4] border-4 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center text-gray-400 hover:bg-white hover:border-blue-400 hover:text-blue-500 cursor-pointer transition-all"><Plus size={48} /><span className="font-bold mt-2">New Mii</span></div>
                    {savedMiis.map(mii => (<div key={mii.id} className="aspect-[3/4] bg-white rounded-3xl shadow-lg flex flex-col items-center justify-center p-4 border border-gray-200 relative group overflow-hidden"><img src={mii.imageUrl} alt={mii.name} className="w-full h-3/4 object-contain group-hover:scale-110 transition-transform" /><div className="absolute bottom-0 w-full bg-gray-100 py-2 text-center font-bold text-gray-600">{mii.name}</div></div>))}
              </div></div>
           </div>
        )}
        {mode === 'CREATE' && (
           <div className="flex-1 flex bg-[#f0f0f0]">
              <div className="w-1/3 bg-white border-r border-gray-200 p-8 flex flex-col gap-6 shadow-xl z-10">
                 <h2 className="text-2xl font-bold text-gray-700 border-b pb-2">Create Mii</h2>
                 <div><label className="block text-sm font-bold text-gray-500 mb-1">Name</label><input className="w-full border-2 border-gray-300 rounded-lg p-2 font-bold" value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></div>
                 <div className="flex gap-4"><div className="flex-1"><label className="block text-sm font-bold text-gray-500 mb-1">Gender</label><select className="w-full border-2 border-gray-300 rounded-lg p-2" value={form.gender} onChange={e => setForm({...form, gender: e.target.value})}><option>Male</option><option>Female</option><option>Other</option></select></div><div className="flex-1"><label className="block text-sm font-bold text-gray-500 mb-1">Color</label><select className="w-full border-2 border-gray-300 rounded-lg p-2" value={form.color} onChange={e => setForm({...form, color: e.target.value})}><option>Red</option><option>Blue</option><option>Green</option><option>Yellow</option><option>Pink</option><option>Black</option></select></div></div>
                 <div><label className="block text-sm font-bold text-gray-500 mb-1">Style Description</label><textarea className="w-full border-2 border-gray-300 rounded-lg p-2 h-24 resize-none" value={form.style} onChange={e => setForm({...form, style: e.target.value})} placeholder="e.g. Spiky hair, glasses, smiling..." /></div>
                 <button onClick={handleGenerate} disabled={generating} className="bg-green-500 text-white font-bold py-3 rounded-full shadow-md hover:bg-green-600 disabled:opacity-50 flex justify-center gap-2 items-center">{generating ? <RefreshCw className="animate-spin" /> : <RefreshCw />} Generate with AI</button>
                 <div className="flex gap-4 mt-auto"><button onClick={() => { setMode('LIST'); setPreviewUrl(null); audioService.playBackSound(); }} className="flex-1 border-2 border-gray-300 text-gray-500 font-bold py-2 rounded-full hover:bg-gray-50">Cancel</button><button onClick={handleSave} disabled={!previewUrl} className="flex-1 bg-blue-500 text-white font-bold py-2 rounded-full shadow-md hover:bg-blue-600 disabled:opacity-50">Save</button></div>
              </div>
              <div className="flex-1 flex items-center justify-center bg-[url('https://www.transparenttextures.com/patterns/checkered-light-emboss.png')]">
                 {generating ? <div className="flex flex-col items-center text-gray-400"><Loader2 size={64} className="animate-spin mb-4" /><span className="font-bold text-xl">Molding Digital Clay...</span></div> : previewUrl ? <div className="bg-white p-8 rounded-[3rem] shadow-2xl border-8 border-white animate-in zoom-in duration-300"><img src={previewUrl} alt="Preview" className="max-h-[60vh] object-contain" /></div> : <div className="text-gray-300 font-bold text-4xl">Preview Area</div>}
              </div>
           </div>
        )}
     </div>
  )
}

export const DiscApp: React.FC<AppProps> = ({ onBack, onBrickSystem, systemData }) => {
   const [state, setState] = useState<'INFO' | 'UPDATING'>('INFO');
   const handleUpdate = () => {
      setState('UPDATING'); audioService.playClickSound();
      setTimeout(() => { if (onBrickSystem) onBrickSystem(); }, 3000);
   };
   return (
      <div className="w-full h-full bg-[#f1f1f1] flex flex-col items-center justify-center font-sans text-gray-800">
         {state === 'INFO' ? (
            <div className="bg-white p-12 rounded-xl shadow-xl max-w-2xl text-center border border-gray-300">
               <AlertTriangle size={64} className="text-yellow-500 mx-auto mb-6" /><h2 className="text-3xl font-bold mb-4">Wii System Update</h2>
               <p className="text-gray-600 mb-8 leading-relaxed">A new system update is available. Updates provide improvements to system stability and new features.<br/><br/><strong className="text-red-500">WARNING:</strong> Unofficial modifications may render your console inoperable.</p>
               <div className="flex gap-4 justify-center"><button onClick={() => { onBack(); audioService.playBackSound(); }} className="px-8 py-3 bg-gray-200 rounded shadow hover:bg-gray-300 font-bold">No</button><button onClick={handleUpdate} className="px-8 py-3 bg-blue-500 text-white rounded shadow hover:bg-blue-600 font-bold">Update</button></div>
            </div>
         ) : (<div className="text-center w-full max-w-xl"><h2 className="text-2xl font-bold mb-8 animate-pulse">Updating System...</h2><div className="w-full bg-gray-300 h-6 rounded-full overflow-hidden border border-gray-400"><div className="h-full bg-blue-500 animate-[width_3s_ease-in-out_forwards]" style={{ width: '0%' }}></div></div><p className="mt-4 text-red-500 font-bold text-sm">Do not touch the Power Button.</p></div>)}
      </div>
   )
}

export const SettingsApp: React.FC<AppProps> = ({ onBack, onSetP1Gamepad, p1IsGamepad }) => {
  const [activeTab, setActiveTab] = useState('INPUT');
  const [detected, setDetected] = useState(false);

  useEffect(() => {
    const loop = () => {
      const gps = navigator.getGamepads();
      let found = false;
      for(const gp of gps) {
        if(gp && gp.buttons[4].pressed && gp.buttons[5].pressed) {
          // Detected LB+RB
          if(onSetP1Gamepad) onSetP1Gamepad(true);
          setDetected(true);
          found = true;
          audioService.playClickSound();
        }
      }
      if(found) setTimeout(() => setDetected(false), 2000);
      requestAnimationFrame(loop);
    };
    const id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, [onSetP1Gamepad]);

  return (
    <div className="w-full h-full bg-[#f0f0f0] font-sans flex flex-col">
       <div className="bg-[#cdcdcd] p-4 flex justify-between items-center shadow-md">
          <h1 className="text-2xl font-bold text-gray-600 flex items-center gap-2"><Settings /> Wii G Settings</h1>
          <button onClick={() => { onBack(); audioService.playBackSound(); }} className="px-6 py-2 bg-white rounded-full font-bold text-gray-600 border border-gray-400">Back</button>
       </div>
       
       <div className="flex-1 flex p-12 gap-12 justify-center items-center">
          <div className="bg-white p-12 rounded-3xl shadow-xl border-4 border-gray-300 max-w-2xl w-full text-center">
             <Gamepad size={80} className="mx-auto text-gray-400 mb-6" />
             <h2 className="text-3xl font-black text-gray-700 mb-4">Controller Settings</h2>
             
             <div className="bg-blue-50 border border-blue-200 p-6 rounded-xl mb-8">
                <p className="text-lg text-gray-600 mb-4 font-bold">Current Player 1 Input:</p>
                <div className="text-3xl font-black text-blue-600 uppercase tracking-widest">
                   {p1IsGamepad ? 'GAMEPAD (Leader)' : 'MOUSE / KEYBOARD'}
                </div>
             </div>

             <div className="space-y-4">
               <p className="text-gray-500">To switch Player 1 to a Controller:</p>
               <div className="inline-block bg-black text-white px-6 py-3 rounded-full font-bold animate-pulse shadow-lg">
                  HOLD <span className="text-yellow-400">LT</span> + <span className="text-yellow-400">RB</span>
               </div>
               <p className="text-xs text-gray-400 mt-2">Does not apply to Wii Remote.</p>
             </div>

             {detected && (
               <div className="mt-8 bg-green-100 text-green-700 p-4 rounded-lg font-bold animate-bounce border border-green-300">
                  CONTROLLER ASSIGNED TO P1!
               </div>
             )}
             
             {!p1IsGamepad && !detected && (
                <button 
                  onClick={() => { if(onSetP1Gamepad) onSetP1Gamepad(false); audioService.playClickSound(); }}
                  className="mt-8 text-sm text-gray-400 underline hover:text-blue-500"
                >
                  Reset to Mouse
                </button>
             )}
          </div>
       </div>
    </div>
  )
}

export const YouTubeApp: React.FC<AppProps> = ({ onBack }) => {
  const [view, setView] = useState<'HOME' | 'SEARCH' | 'PLAYER'>('HOME');
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);
  
  const SAMPLE_VIDEOS: Video[] = [
    { id: '1', title: 'Big Buck Bunny Trailer', thumbnail: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', duration: '0:30', author: 'Blender' },
    { id: '2', title: 'Elephant Dream', thumbnail: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', duration: '1:00', author: 'Blender' },
    { id: '3', title: 'For Bigger Blazes', thumbnail: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', duration: '0:15', author: 'Google' },
    { id: '4', title: 'Wii G Gameplay Reveal', thumbnail: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4', duration: '2:10', author: 'Nintendo Fan' },
  ];

  const handlePlay = (v: Video) => {
    setActiveVideo(v);
    setView('PLAYER');
  };

  return (
    <div className="w-full h-full bg-[#e6e6e6] font-sans flex flex-col relative">
       {/* Retro Header */}
       <div className="bg-[#cc181e] h-20 flex items-center px-8 shadow-lg z-20">
          <div className="bg-white text-[#cc181e] p-2 rounded-lg mr-4"><Youtube size={32} fill="#cc181e" /></div>
          <h1 className="text-white font-bold text-3xl tracking-tighter">YouTube</h1>
          <div className="ml-auto flex gap-4">
             <button onClick={() => setView('SEARCH')} className="text-white hover:bg-white/20 p-2 rounded-full"><Search size={32}/></button>
          </div>
       </div>

       {view !== 'PLAYER' && (
         <div className="flex flex-1 overflow-hidden">
            {/* Sidebar */}
            <div className="w-64 bg-[#333] text-gray-300 flex flex-col p-4 gap-2 shadow-inner">
               <div className={`p-4 rounded font-bold text-xl cursor-pointer ${view === 'HOME' ? 'bg-[#cc181e] text-white' : 'hover:bg-white/10'}`} onClick={() => setView('HOME')}>Home</div>
               <div className="p-4 rounded font-bold text-xl cursor-pointer hover:bg-white/10">Trending</div>
               <div className="p-4 rounded font-bold text-xl cursor-pointer hover:bg-white/10">History</div>
               <div className="mt-auto p-4 rounded font-bold text-xl cursor-pointer hover:bg-red-900 text-red-300 border border-red-900" onClick={onBack}>Exit App</div>
            </div>

            {/* Grid */}
            <div className="flex-1 p-8 overflow-y-auto bg-[#f1f1f1]">
               <h2 className="text-2xl font-bold text-gray-600 mb-6 border-b pb-2 border-gray-300">Recommended</h2>
               <div className="grid grid-cols-3 gap-6">
                  {SAMPLE_VIDEOS.map(v => (
                     <div key={v.id} onClick={() => handlePlay(v)} className="bg-white p-3 shadow-md hover:scale-105 transition-transform cursor-pointer group border border-gray-300">
                        <div className="relative aspect-video bg-black mb-3 group-hover:opacity-90">
                           <img src={v.thumbnail} alt={v.title} className="w-full h-full object-cover" />
                           <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1 font-bold">{v.duration}</div>
                           <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100"><Play size={48} className="text-white fill-white drop-shadow-md"/></div>
                        </div>
                        <h3 className="font-bold text-gray-800 leading-tight mb-1">{v.title}</h3>
                        <p className="text-sm text-gray-500">{v.author}</p>
                     </div>
                  ))}
               </div>
            </div>
         </div>
       )}

       {/* Video Player Overlay */}
       {view === 'PLAYER' && activeVideo && (
          <div className="absolute inset-0 bg-black z-50 flex flex-col items-center justify-center">
             <div className="relative w-full h-full max-h-[80vh] aspect-video bg-black">
                <video src={activeVideo.url} autoPlay controls className="w-full h-full" />
                <button 
                  onClick={() => setView('HOME')} 
                  className="absolute top-4 left-4 bg-white/20 hover:bg-white/40 text-white px-4 py-2 rounded font-bold backdrop-blur-md"
                >
                   Back
                </button>
             </div>
             <div className="w-full bg-[#222] p-8 text-white">
                <h2 className="text-2xl font-bold">{activeVideo.title}</h2>
                <p className="text-gray-400">{activeVideo.author} • 1M views</p>
             </div>
          </div>
       )}
    </div>
  )
}

export const HomebrewApp: React.FC<AppProps> = ({ onBack }) => {
  const [app, setApp] = useState<'MENU' | 'YOUTUBE'>('MENU');

  if(app === 'YOUTUBE') return <YouTubeApp onBack={() => setApp('MENU')} />;

  return (
    <div className="w-full h-full bg-[#009ac7] relative overflow-hidden font-sans">
       {/* Bubble Background */}
       <div className="absolute inset-0 z-0 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-white/20 blur-sm animate-pulse"></div>
          <div className="absolute top-3/4 left-1/3 w-24 h-24 rounded-full bg-white/20 blur-sm animate-pulse delay-700"></div>
          <div className="absolute top-1/2 left-3/4 w-48 h-48 rounded-full bg-white/20 blur-sm animate-pulse delay-300"></div>
       </div>

       <div className="relative z-10 p-8 flex flex-col h-full">
          <div className="flex justify-between items-center text-white mb-12">
             <h1 className="text-4xl font-bold drop-shadow-md tracking-wider">The Homebrew Channel</h1>
             <div className="flex gap-4 items-center">
                 <Globe className="animate-pulse" />
                 <span className="font-mono">1.2.0 IOS58</span>
             </div>
          </div>

          <div className="flex-1 grid grid-cols-4 gap-8">
             <div 
               onClick={() => setApp('YOUTUBE')}
               className="bg-white/10 hover:bg-white/30 border border-white/20 p-4 rounded-xl flex flex-col items-center cursor-pointer transition-colors backdrop-blur-sm"
             >
                <div className="w-full aspect-video bg-black mb-4 flex items-center justify-center relative group">
                    <Youtube size={64} className="text-red-500" />
                </div>
                <span className="text-white font-bold text-xl drop-shadow-sm">YouTube</span>
                <span className="text-white/70 text-sm">v4.1.2</span>
             </div>
          </div>

          <div className="flex justify-center mt-auto">
             <button onClick={onBack} className="bg-white/20 hover:bg-white/40 text-white px-12 py-4 rounded-full font-bold backdrop-blur-md border border-white/30 text-xl transition-all">
                Exit to System Menu
             </button>
          </div>
       </div>
    </div>
  )
}

export const CoopApp: React.FC<AppProps> = ({ onBack }) => {
  const [mode, setMode] = useState<'MENU' | 'ADVENTURE' | 'PARTY'>('MENU');
  const [partyGame, setPartyGame] = useState<number>(0); 
  const [scores, setScores] = useState<number[]>([0,0,0,0]);

  const [timeLeft, setTimeLeft] = useState(30);
  const [partyState, setPartyState] = useState<'INTRO' | 'PLAY' | 'RESULTS'>('INTRO');
  
  const [targets, setTargets] = useState<{x:number, y:number, id:number}[]>([]);

  useEffect(() => {
     if(mode === 'PARTY' && partyGame > 0 && partyState === 'PLAY') {
        const t = setInterval(() => {
           setTimeLeft(prev => {
              if(prev <= 1) {
                 setPartyState('RESULTS');
                 return 0;
              }
              return prev - 1;
           });
        }, 1000);
        return () => clearInterval(t);
     }
  }, [mode, partyGame, partyState]);

  const handlePartyClick = (idx: number) => {
     if(partyState !== 'PLAY') return;
     setScores(prev => {
        const n = [...prev];
        n[0] += 10;
        return n;
     });
     audioService.playClickSound();
     setTargets([{x: Math.random()*80 + 10, y: Math.random()*60 + 20, id: Date.now()}]);
  };

  const startPartyGame = (id: number) => {
     setPartyGame(id);
     setPartyState('INTRO');
     setTimeLeft(30);
     setTargets([{x: 50, y: 50, id: 1}]);
     setTimeout(() => setPartyState('PLAY'), 2000);
  };

  const renderParty = () => {
     if(partyGame === 0) {
        return (
           <div className="h-full flex flex-col items-center justify-center bg-yellow-100 font-sans">
              <h1 className="text-6xl font-black text-orange-500 mb-12 tracking-tighter">PARTY MODE</h1>
              <div className="grid grid-cols-5 gap-4">
                 {['Balloon Pop', 'Sumo Push', 'Coin Dash', 'Mash Master', 'Reaction'].map((n, i) => (
                    <button key={i} onClick={() => startPartyGame(i+1)} className="w-40 h-40 bg-white border-4 border-orange-300 rounded-xl hover:scale-105 shadow-xl flex flex-col items-center justify-center font-bold text-gray-600 text-center p-2">
                       <span className="text-4xl mb-2">{['🎈','🤼','🪙','🔘','⚡'][i]}</span>
                       {n}
                    </button>
                 ))}
              </div>
              <button onClick={() => setMode('MENU')} className="mt-12 text-gray-500 font-bold">Back</button>
           </div>
        )
     }

     return (
        <div className="h-full bg-[#333] relative flex flex-col items-center text-white font-sans select-none">
           <div className="w-full h-20 bg-gray-800 flex items-center justify-between px-8 border-b-4 border-orange-500">
              <div className="text-3xl font-black text-orange-400">{['Balloon Pop', 'Sumo Push', 'Coin Dash', 'Mash Master', 'Reaction'][partyGame-1]}</div>
              <div className="text-4xl font-mono">{timeLeft}s</div>
           </div>

           <div className="flex-1 w-full relative bg-gray-700 overflow-hidden cursor-crosshair" onClick={() => handlePartyClick(0)}>
              {partyState === 'INTRO' && <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-6xl font-black animate-pulse">READY?</div>}
              {partyState === 'RESULTS' && (
                 <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-20">
                    <h2 className="text-6xl font-black text-yellow-400 mb-8">TIME UP!</h2>
                    <div className="bg-white text-black p-8 rounded-xl min-w-[300px]">
                       <h3 className="text-2xl font-bold mb-4 border-b pb-2">Results</h3>
                       {scores.map((s, i) => (
                          <div key={i} className="flex justify-between text-xl font-bold mb-2">
                             <span style={{color: ['#3b82f6','#22c55e','#ef4444','#eab308'][i]}}>Player {i+1}</span>
                             <span>{s} pts</span>
                          </div>
                       ))}
                    </div>
                    <button onClick={() => setPartyGame(0)} className="mt-8 bg-orange-500 px-8 py-3 rounded-full font-bold">Back to Lobby</button>
                 </div>
              )}

              {partyGame === 1 && partyState === 'PLAY' && targets.map(t => (
                 <div key={t.id} className="absolute text-6xl animate-bounce transition-all duration-75" style={{ left: `${t.x}%`, top: `${t.y}%` }}>
                    🎈
                 </div>
              ))}
              
              {partyGame !== 1 && partyState === 'PLAY' && (
                 <div className="flex items-center justify-center h-full text-gray-500 text-2xl font-bold">
                    (Minigame Logic Simulation Active) <br/> Mash buttons to score!
                 </div>
              )}
           </div>
        </div>
     )
  };

  if (mode === 'ADVENTURE') {
     return (
        <div className="h-full relative bg-gray-800">
           <button onClick={() => setMode('MENU')} className="absolute top-4 left-4 z-50 bg-white px-4 py-2 rounded shadow text-black font-bold">Exit</button>
           <div className="h-full flex items-center justify-center">
              {/* Reuse Mario logic but with Pico Park style sprites */}
              <MarioBrosGame p1IsGamepad={true} isPicoPark={true} />
           </div>
        </div>
     )
  }

  if (mode === 'PARTY') return renderParty();

  return (
    <div className="w-full h-full bg-white font-sans flex flex-col items-center justify-center gap-8">
       <h1 className="text-6xl font-black text-gray-800 tracking-tighter">CO-OP CHANNEL</h1>
       <div className="flex gap-12">
          <div onClick={() => setMode('ADVENTURE')} className="w-80 h-96 bg-blue-500 text-white rounded-3xl flex flex-col items-center justify-center hover:scale-105 transition-transform cursor-pointer shadow-2xl border-8 border-blue-600">
             <Gamepad2 size={96} className="mb-6"/>
             <h2 className="text-4xl font-bold">Adventure</h2>
             <p className="mt-4 text-blue-200 font-bold">25 Levels • 4 Players</p>
          </div>
          <div onClick={() => setMode('PARTY')} className="w-80 h-96 bg-orange-500 text-white rounded-3xl flex flex-col items-center justify-center hover:scale-105 transition-transform cursor-pointer shadow-2xl border-8 border-orange-600">
             <Trophy size={96} className="mb-6"/>
             <h2 className="text-4xl font-bold">Party Mode</h2>
             <p className="mt-4 text-orange-200 font-bold">5 Minigames • Competitive</p>
          </div>
       </div>
       <button onClick={onBack} className="mt-8 text-gray-400 font-bold hover:text-gray-600">Back to Wii Menu</button>
    </div>
  )
}

export const WiiSportsApp: React.FC<AppProps> = ({ onBack }) => {
  const [sport, setSport] = useState<'MENU' | 'BASKETBALL' | 'GOLF'>('MENU');
  const [score, setScore] = useState(0);
  const [gameState, setGameState] = useState<'IDLE'|'PLAYING'|'OVER'>('IDLE');

  // Basketball State
  const [power, setPower] = useState(0);
  const [charging, setCharging] = useState(false);
  const [balls, setBalls] = useState(5);
  
  // Golf State
  const [golfPhase, setGolfPhase] = useState<'AIM'|'POWER'|'ACCURACY'>('AIM');
  const [swingPower, setSwingPower] = useState(0);
  const [swingAcc, setSwingAcc] = useState(0);
  const [holeDist, setHoleDist] = useState(350);

  useEffect(() => {
    let interval: any;
    if (sport === 'BASKETBALL' && charging) {
      interval = setInterval(() => {
        setPower(p => (p >= 100 ? 0 : p + 2));
      }, 16);
    }
    return () => clearInterval(interval);
  }, [charging, sport]);

  const handleBasketClick = () => {
    if (balls <= 0) return;
    if (!charging) {
      setCharging(true);
      setPower(0);
    } else {
      setCharging(false);
      setBalls(b => b - 1);
      // Logic: Sweet spot is 80-90
      if (power > 80 && power < 95) {
        setScore(s => s + 3);
        audioService.playClickSound();
      }
      if (balls <= 1) setGameState('OVER');
    }
  };

  const handleGolfClick = () => {
    if (golfPhase === 'AIM') {
       setGolfPhase('POWER');
       // Animation loop handled via requestRef if fully implemented, simplistic here
       setSwingPower(Math.random() * 100); 
    } else if (golfPhase === 'POWER') {
       setGolfPhase('ACCURACY');
       setSwingAcc(Math.random() * 100);
    } else {
       // Hit
       const drive = (swingPower / 100) * 200;
       setHoleDist(d => Math.max(0, d - drive));
       setGolfPhase('AIM');
       if (holeDist - drive <= 10) setGameState('OVER');
    }
  };

  if (sport === 'MENU') {
    return (
      <div className="w-full h-full bg-gradient-to-b from-blue-400 to-blue-600 flex flex-col items-center justify-center text-white relative font-sans overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')] opacity-20"></div>
        <div className="z-10 text-center animate-in fade-in zoom-in duration-500">
           <div className="bg-white text-blue-500 text-6xl font-black italic px-12 py-6 rounded-full shadow-xl mb-8 transform -rotate-3 border-4 border-blue-200">Wii Sports</div>
           <div className="flex gap-8">
              <button onClick={() => { setSport('BASKETBALL'); setGameState('PLAYING'); setBalls(5); setScore(0); }} className="bg-orange-500 hover:bg-orange-400 px-8 py-12 rounded-2xl font-bold text-2xl shadow-lg border-4 border-orange-300 w-48">Basketball</button>
              <button onClick={() => { setSport('GOLF'); setGameState('PLAYING'); setHoleDist(350); }} className="bg-green-600 hover:bg-green-500 px-8 py-12 rounded-2xl font-bold text-2xl shadow-lg border-4 border-green-400 w-48">Golf</button>
           </div>
           <button onClick={onBack} className="mt-12 bg-white/20 hover:bg-white/40 text-white font-bold px-8 py-3 rounded-full backdrop-blur-md border-2 border-white/50 transition-all">Return to Menu</button>
        </div>
      </div>
    );
  }

  if (sport === 'BASKETBALL') {
     return (
        <div className="w-full h-full bg-orange-50 relative flex flex-col font-sans" onMouseDown={handleBasketClick}>
           <div className="bg-orange-600 p-4 text-white flex justify-between font-bold text-2xl shadow-md">
              <span>Balls: {balls}</span>
              <span>Score: {score}</span>
           </div>
           <div className="flex-1 flex flex-col items-center justify-center relative">
              {/* Basket */}
              <div className="w-32 h-2 border-4 border-red-600 bg-white mb-24"></div>
              <div className="w-4 h-32 bg-gray-400"></div>
              
              {/* Power Meter */}
              <div className="absolute right-10 top-1/2 -translate-y-1/2 w-12 h-64 bg-gray-200 rounded-full border-4 border-gray-400 overflow-hidden">
                 <div className="absolute bottom-0 w-full bg-red-500 transition-all duration-75" style={{ height: `${power}%` }}></div>
                 <div className="absolute top-[10%] w-full h-[15%] bg-green-400/50"></div>
              </div>
              
              {gameState === 'OVER' && <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-6xl font-black">FINISHED!</div>}
              
              <div className="mt-12 text-gray-500 font-bold animate-pulse">Click & Hold to Shoot</div>
              <button onClick={() => setSport('MENU')} className="absolute bottom-4 left-4 bg-gray-200 px-4 py-2 rounded font-bold text-gray-600">Quit</button>
           </div>
        </div>
     )
  }

  if (sport === 'GOLF') {
     return (
        <div className="w-full h-full bg-green-800 relative flex flex-col font-sans" onClick={handleGolfClick}>
           <div className="bg-white/90 p-4 flex justify-between font-bold text-xl shadow-md z-10">
              <span>Hole 1 Par 4</span>
              <span>Dist: {holeDist.toFixed(0)}y</span>
              <span>Wind: 5mph N</span>
           </div>
           <div className="flex-1 relative overflow-hidden bg-[url('https://www.transparenttextures.com/patterns/grass.png')]">
              <div className="absolute top-10 left-1/2 -translate-x-1/2 w-8 h-8 bg-black rounded-full border-4 border-gray-300"></div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-4 h-[400px] bg-green-400 opacity-20"></div>
              
              <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex flex-col items-center">
                 <div className="text-white font-bold mb-2 shadow-black drop-shadow-md">{golfPhase}</div>
                 <div className="w-64 h-8 bg-black rounded-full border-2 border-white overflow-hidden relative">
                    <div className="h-full bg-yellow-400" style={{ width: `${swingPower}%` }}></div>
                    <div className="absolute top-0 w-1 h-full bg-white" style={{ left: `${swingAcc}%` }}></div>
                 </div>
              </div>
           </div>
           {gameState === 'OVER' && <div className="absolute inset-0 z-20 bg-black/50 flex items-center justify-center text-white text-6xl font-black">NICE ON!</div>}
           <button onClick={() => setSport('MENU')} className="absolute bottom-4 left-4 bg-gray-200 px-4 py-2 rounded font-bold text-gray-600 z-30">Quit</button>
        </div>
     )
  }
  return null;
};

export const ZeldaApp: React.FC<AppProps> = ({ onBack }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [link, setLink] = useState({x: 100, y: 100, dir: 'DOWN', attacking: false});
  const [rupees, setRupees] = useState(0);

  useEffect(() => {
     const cvs = canvasRef.current;
     if(!cvs) return;
     const ctx = cvs.getContext('2d');
     if(!ctx) return;
     cvs.width = window.innerWidth; cvs.height = window.innerHeight;

     const enemies = [{x: 300, y: 300, dead: false}];
     
     const loop = () => {
        // Clear
        ctx.fillStyle = '#2d2d2d'; // Dungeon Floor
        ctx.fillRect(0,0,cvs.width, cvs.height);
        
        // Link
        ctx.fillStyle = '#00ff00';
        ctx.fillRect(link.x, link.y, 40, 40);
        
        // Sword
        if(link.attacking) {
           ctx.fillStyle = '#ffffff';
           if(link.dir === 'DOWN') ctx.fillRect(link.x+15, link.y+40, 10, 30);
           if(link.dir === 'UP') ctx.fillRect(link.x+15, link.y-30, 10, 30);
           if(link.dir === 'LEFT') ctx.fillRect(link.x-30, link.y+15, 30, 10);
           if(link.dir === 'RIGHT') ctx.fillRect(link.x+40, link.y+15, 30, 10);
        }

        // Enemies
        enemies.forEach(e => {
           if(e.dead) return;
           ctx.fillStyle = '#ff0000'; // Octorok
           ctx.fillRect(e.x, e.y, 40, 40);
           
           // Simple AI
           if(Math.random() > 0.95) e.x += (Math.random()-0.5)*10;
           if(Math.random() > 0.95) e.y += (Math.random()-0.5)*10;
           
           // Collision with sword
           if(link.attacking) {
              const dx = link.x - e.x; const dy = link.y - e.y;
              if(Math.sqrt(dx*dx + dy*dy) < 60) e.dead = true;
           }
        });

        requestAnimationFrame(loop);
     };
     const id = requestAnimationFrame(loop);
     
     const handleKey = (e: KeyboardEvent) => {
        const speed = 15;
        if(e.key === 'w') { setLink(l => ({...l, y: l.y-speed, dir: 'UP'})); }
        if(e.key === 's') { setLink(l => ({...l, y: l.y+speed, dir: 'DOWN'})); }
        if(e.key === 'a') { setLink(l => ({...l, x: l.x-speed, dir: 'LEFT'})); }
        if(e.key === 'd') { setLink(l => ({...l, x: l.x+speed, dir: 'RIGHT'})); }
        if(e.key === ' ') { setLink(l => ({...l, attacking: true})); setTimeout(() => setLink(l => ({...l, attacking: false})), 200); }
     };
     window.addEventListener('keydown', handleKey);
     return () => { cancelAnimationFrame(id); window.removeEventListener('keydown', handleKey); }
  }, [link]);

  return (
      <div className="w-full h-full bg-black relative">
         <canvas ref={canvasRef} className="block w-full h-full" />
         <div className="absolute top-4 left-4 text-white font-mono text-xl font-bold flex gap-4">
             <div className="flex items-center gap-1 text-red-500"><Heart fill="red"/> x 3</div>
             <div className="text-green-400">Rupees: {rupees}</div>
         </div>
         <button onClick={onBack} className="absolute top-4 right-4 text-gray-500 text-xs">RESET</button>
      </div>
  );
};

export const PlayableGame: React.FC<AppProps> = ({ onBack, activeGame, p1IsGamepad }) => {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'h') { audioService.playBackSound(); onBack(); }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onBack]);

  if (!activeGame) return null;

  return (
    <div className="w-full h-full relative">
       <div className="absolute inset-0 z-0">
          {activeGame.engine === 'PLATFORMER' && <MarioBrosGame p1IsGamepad={p1IsGamepad} />} 
          {activeGame.engine === 'SHOOTER' && <GeminiAdventureGame p1IsGamepad={p1IsGamepad} />}
          {activeGame.engine === 'SPORTS' && <WiiSportsApp onBack={onBack} />}
          {activeGame.engine === 'EMULATOR' && <ZeldaApp onBack={onBack} />}
       </div>
    </div>
  )
}

const MarioBrosGame: React.FC<{ p1IsGamepad?: boolean, isPicoPark?: boolean }> = ({ p1IsGamepad, isPicoPark = false }) => {
   const canvasRef = useRef<HTMLCanvasElement>(null);
   const [level, setLevel] = useState(1);
   
   // State kept in ref for performance loop
   const gameState = useRef({
      players: [
         {id: 1, x: 100, y: 100, vx: 0, vy: 0, grounded: false, color: '#ef4444', dead: false}
      ],
      enemies: [
         {x: 400, y: 300, vx: -2, type: 'GOOMBA', dead: false}
      ],
      particles: [] as any[]
   });

   useEffect(() => {
      if(isPicoPark) {
         // Add 3 more players for Pico Park
         gameState.current.players = [
            {id: 1, x: 100, y: 100, vx: 0, vy: 0, grounded: false, color: '#3b82f6', dead: false},
            {id: 2, x: 150, y: 100, vx: 0, vy: 0, grounded: false, color: '#22c55e', dead: false},
            {id: 3, x: 200, y: 100, vx: 0, vy: 0, grounded: false, color: '#ef4444', dead: false},
            {id: 4, x: 250, y: 100, vx: 0, vy: 0, grounded: false, color: '#eab308', dead: false},
         ];
      }
   }, [isPicoPark]);

   useEffect(() => {
     const cvs = canvasRef.current;
     if (!cvs) return;
     const ctx = cvs.getContext('2d');
     if (!ctx) return;
     
     // Resize
     cvs.width = window.innerWidth; 
     cvs.height = window.innerHeight;

     // Level Gen
     const blocks: any[] = [];
     const groundY = cvs.height - 80;
     for(let i=0; i<30; i++) blocks.push({x: i*60, y: groundY, w: 60, h: 80, type: 'ground'});
     blocks.push({x: 300, y: groundY - 150, w: 180, h: 40, type: 'platform'});
     blocks.push({x: 600, y: groundY - 250, w: 60, h: 60, type: 'qblock'});
     
     // Loop
     const loop = () => {
        const gps = navigator.getGamepads();
        
        // Update Players
        gameState.current.players.forEach((p, idx) => {
           if(p.dead) return;
           
           // Physics
           p.vy += 0.8; // Gravity
           p.vx *= 0.85; // Friction

           // Input
           let jump = false;
           let move = 0;

           // P1 Control logic
           if (idx === 0) {
              if (p1IsGamepad) {
                 const gp = gps[0];
                 if(gp) {
                    if(Math.abs(gp.axes[0]) > 0.2) move = gp.axes[0];
                    if(gp.buttons[0].pressed) jump = true;
                 }
              } else {
                 // Keyboard hack for P1
                 // (Ideally use event listener state, simplified here for compactness)
              }
           } else {
              // P2-P4
              const gp = gps[idx]; // map p2 to gp1, p3 to gp2 etc. if p1 is kb? No, Cursor.tsx handles mapping.
              // Assuming direct mapping for simplicity
              if(gp) {
                 if(Math.abs(gp.axes[0]) > 0.2) move = gp.axes[0];
                 if(gp.buttons[0].pressed) jump = true;
              }
           }
           
           if(move !== 0) p.vx += move * 1.5;
           if(jump && p.grounded) { p.vy = -18; p.grounded = false; }
           
           // Move
           p.x += p.vx;
           p.y += p.vy;

           // Collisions
           p.grounded = false;
           blocks.forEach(b => {
              if (p.x < b.x + b.w && p.x + 40 > b.x && p.y < b.y + b.h && p.y + 60 > b.y) {
                  // Simple resolution
                  if(p.vy > 0 && p.y + 60 - p.vy <= b.y) {
                     p.y = b.y - 60; p.vy = 0; p.grounded = true;
                  } else if (p.vy < 0 && p.y - p.vy >= b.y + b.h) {
                     p.y = b.y + b.h; p.vy = 0;
                  } else if (p.vx > 0) { p.x = b.x - 40; p.vx = 0; }
                  else if (p.vx < 0) { p.x = b.x + b.w; p.vx = 0; }
              }
           });
           
           // Death plane
           if(p.y > cvs.height) p.dead = true;
        });

        // Enemies
        if(!isPicoPark) {
           gameState.current.enemies.forEach(e => {
              if(e.dead) return;
              e.x += e.vx;
              if(e.x < 0 || e.x > cvs.width) e.vx *= -1;
              
              // Interact with players
              gameState.current.players.forEach(p => {
                 if(p.dead) return;
                 // AABB
                 if (p.x < e.x + 40 && p.x + 40 > e.x && p.y < e.y + 40 && p.y + 60 > e.y) {
                    if (p.vy > 0 && p.y + 60 - p.vy < e.y + 10) {
                       // Stomp
                       e.dead = true; p.vy = -10;
                    } else {
                       // Hurt
                       p.dead = true;
                    }
                 }
              });
           });
        }

        // Render
        ctx.fillStyle = isPicoPark ? '#f0f9ff' : '#5c94fc'; 
        ctx.fillRect(0,0,cvs.width, cvs.height);

        // Blocks
        blocks.forEach(b => {
           ctx.fillStyle = b.type === 'qblock' ? '#fbbf24' : '#c84c0c';
           ctx.fillRect(b.x, b.y, b.w, b.h);
           ctx.lineWidth = 2; ctx.strokeStyle = 'black'; ctx.strokeRect(b.x, b.y, b.w, b.h);
        });

        // Players
        gameState.current.players.forEach(p => {
           if(p.dead) return;
           ctx.fillStyle = p.color;
           ctx.fillRect(p.x, p.y, 40, 60);
           // Eyes
           ctx.fillStyle = 'white'; ctx.fillRect(p.x + (p.vx > 0 ? 25 : 5), p.y + 10, 10, 10);
        });

        // Enemies
        if(!isPicoPark) {
           gameState.current.enemies.forEach(e => {
              if(e.dead) return;
              ctx.fillStyle = '#7f1d1d'; // Goomba color
              ctx.fillRect(e.x, e.y, 40, 40);
           });
        }

        requestAnimationFrame(loop);
     };
     const id = requestAnimationFrame(loop);
     
     // Keyboard Listeners for P1 if not gamepad
     const kDown = (e: KeyboardEvent) => {
        if(p1IsGamepad) return;
        const p1 = gameState.current.players[0];
        if(e.key === 'a') p1.vx = -8;
        if(e.key === 'd') p1.vx = 8;
        if(e.key === ' ' && p1.grounded) { p1.vy = -18; p1.grounded = false; }
     };
     const kUp = (e: KeyboardEvent) => {
        if(p1IsGamepad) return;
        // Simple release logic
     };
     window.addEventListener('keydown', kDown);
     window.addEventListener('keyup', kUp);

     return () => { cancelAnimationFrame(id); window.removeEventListener('keydown', kDown); window.removeEventListener('keyup', kUp); }
   }, [level, isPicoPark, p1IsGamepad]);

   return (
      <div className="relative w-full h-full">
         <canvas ref={canvasRef} className="block w-full h-full" />
         <div className="absolute top-4 left-4 font-bold text-white text-2xl drop-shadow-md">
            WORLD {level}-1
         </div>
      </div>
   );
}

const GeminiAdventureGame: React.FC<{p1IsGamepad?: boolean}> = ({p1IsGamepad}) => {
   const canvasRef = useRef<HTMLCanvasElement>(null);
   const [wave, setWave] = useState(1);
   const state = useRef({
      player: { x: 400, y: 300, hp: 100 },
      bullets: [] as {x: number, y: number, vx: number, vy: number}[],
      enemies: [] as {x: number, y: number, hp: number, type: 'BUG'}[]
   });

   useEffect(() => {
      const cvs = canvasRef.current;
      if(!cvs) return;
      const ctx = cvs.getContext('2d');
      if(!ctx) return;
      cvs.width = window.innerWidth; cvs.height = window.innerHeight;

      // Spawn Loop
      const spawnTimer = setInterval(() => {
         if(state.current.enemies.length < wave * 3) {
            state.current.enemies.push({
               x: Math.random() * cvs.width,
               y: Math.random() < 0.5 ? -50 : cvs.height + 50,
               hp: 2,
               type: 'BUG'
            });
         }
      }, 2000 / wave);

      const loop = () => {
         // Clear
         ctx.fillStyle = '#1a0b2e'; // Dark Purple
         ctx.fillRect(0,0,cvs.width, cvs.height);
         
         // Grid
         ctx.strokeStyle = '#4c1d95'; ctx.lineWidth = 1;
         for(let i=0; i<cvs.width; i+=50) { ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i,cvs.height); ctx.stroke(); }
         for(let i=0; i<cvs.height; i+=50) { ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(cvs.width,i); ctx.stroke(); }

         // Player
         const p = state.current.player;
         ctx.fillStyle = '#06b6d4'; // Cyan Neon
         ctx.shadowBlur = 15; ctx.shadowColor = '#06b6d4';
         ctx.beginPath(); ctx.arc(p.x, p.y, 20, 0, Math.PI*2); ctx.fill();
         ctx.shadowBlur = 0;

         // Input (P1 Mouse/KB or Gamepad)
         const gp = navigator.getGamepads()[0];
         if(p1IsGamepad && gp) {
             if(Math.abs(gp.axes[0]) > 0.1) p.x += gp.axes[0] * 5;
             if(Math.abs(gp.axes[1]) > 0.1) p.y += gp.axes[1] * 5;
             // Right Stick Shoot
             if(Math.abs(gp.axes[2]) > 0.5 || Math.abs(gp.axes[3]) > 0.5) {
                 if(Math.random() > 0.8) { // Fire rate limiter
                    state.current.bullets.push({x: p.x, y: p.y, vx: gp.axes[2]*15, vy: gp.axes[3]*15});
                 }
             }
         }

         // Bullets
         ctx.fillStyle = '#f472b6'; // Pink Neon
         state.current.bullets.forEach((b, i) => {
            b.x += b.vx; b.y += b.vy;
            ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, Math.PI*2); ctx.fill();
            if(b.x < 0 || b.x > cvs.width || b.y < 0 || b.y > cvs.height) state.current.bullets.splice(i, 1);
         });

         // Enemies
         state.current.enemies.forEach((e, i) => {
            const angle = Math.atan2(p.y - e.y, p.x - e.x);
            e.x += Math.cos(angle) * 2;
            e.y += Math.sin(angle) * 2;
            
            ctx.fillStyle = '#ef4444'; // Red Neon
            ctx.fillRect(e.x-15, e.y-15, 30, 30);

            // Bullet Collisions
            state.current.bullets.forEach((b, bi) => {
               const dist = Math.sqrt((b.x-e.x)**2 + (b.y-e.y)**2);
               if(dist < 20) {
                  e.hp--;
                  state.current.bullets.splice(bi, 1);
                  if(e.hp <= 0) state.current.enemies.splice(i, 1);
               }
            });
         });

         requestAnimationFrame(loop);
      };
      const id = requestAnimationFrame(loop);
      
      const mouseMove = (e: MouseEvent) => {
         if(!p1IsGamepad) { state.current.player.x = e.clientX; state.current.player.y = e.clientY; }
      };
      const mouseDown = (e: MouseEvent) => {
         if(!p1IsGamepad) {
            // Shoot towards center or just straight up? 
            // Simple: Shoot up
            state.current.bullets.push({x: state.current.player.x, y: state.current.player.y, vx: 0, vy: -15});
         }
      }
      window.addEventListener('mousemove', mouseMove);
      window.addEventListener('mousedown', mouseDown);

      return () => { 
         cancelAnimationFrame(id); clearInterval(spawnTimer);
         window.removeEventListener('mousemove', mouseMove);
         window.removeEventListener('mousedown', mouseDown);
      }
   }, [wave, p1IsGamepad]);

   return (
      <div className="relative w-full h-full bg-black cursor-crosshair">
         <canvas ref={canvasRef} className="block w-full h-full" />
         <div className="absolute top-4 left-4 text-cyan-400 font-mono text-2xl font-bold">WAVE {wave}</div>
         <div className="absolute top-4 right-4 text-pink-400 font-mono text-xl">HP: {100}%</div>
      </div>
   );
}
