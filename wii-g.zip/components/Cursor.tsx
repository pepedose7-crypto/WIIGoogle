
import React, { useEffect, useState, useRef } from 'react';

// SVG for the cursor hand
const HandCursorSvg = ({ rotation, color, label }: { rotation: number, color: string, label: string }) => (
  <div 
    style={{ transform: `rotate(${rotation}deg)`, transition: 'transform 0.1s ease-out' }}
    className="relative drop-shadow-lg"
  >
    <svg 
      width="48" 
      height="48" 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <path 
        d="M7 2L17 12L12 13L15 20L11 22L8 15L3 18L7 2Z" 
        fill="white" 
        stroke="#4b5563" 
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
    </svg>
    {/* Player Badge */}
    <div 
      className="absolute -bottom-4 left-0 text-[10px] font-bold px-1.5 py-0.5 rounded-md text-white border border-white shadow-sm"
      style={{ backgroundColor: color }}
    >
      {label}
    </div>
  </div>
);

interface PlayerCursor {
  id: number;
  type: 'MOUSE' | 'GAMEPAD';
  padIndex?: number;
  x: number;
  y: number;
  rotation: number;
  clicked: boolean;
  color: string;
  label: string;
}

const PLAYER_COLORS = [
  '#3b82f6', // P1 - Blue
  '#22c55e', // P2 - Green
  '#ef4444', // P3 - Red
  '#eab308'  // P4 - Yellow
];

interface CursorProps {
  p1IsGamepad?: boolean;
}

const Cursor: React.FC<CursorProps> = ({ p1IsGamepad = false }) => {
  // P1 defaults to Mouse, unless p1IsGamepad is true then it swaps logic in loop
  const [cursors, setCursors] = useState<PlayerCursor[]>([
    { id: 1, type: 'MOUSE', x: -100, y: -100, rotation: 0, clicked: false, color: PLAYER_COLORS[0], label: 'P1' }
  ]);
  
  const cursorsRef = useRef<PlayerCursor[]>([
    { id: 1, type: 'MOUSE', x: -100, y: -100, rotation: 0, clicked: false, color: PLAYER_COLORS[0], label: 'P1' }
  ]);
  
  const mousePos = useRef({ x: -100, y: -100 });
  const requestRef = useRef<number | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseDown = () => {
       const p1 = cursorsRef.current.find(c => c.id === 1);
       if(p1 && !p1IsGamepad) p1.clicked = true;
    };
    const handleMouseUp = () => {
       const p1 = cursorsRef.current.find(c => c.id === 1);
       if(p1 && !p1IsGamepad) p1.clicked = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [p1IsGamepad]);

  const animate = () => {
    const gamepads = navigator.getGamepads();
    const screenCenterX = window.innerWidth / 2;

    // 1. Update P1
    const p1 = cursorsRef.current.find(c => c.id === 1);
    if (p1) {
      if (!p1IsGamepad) {
        // MOUSE MODE
        p1.type = 'MOUSE';
        p1.x += (mousePos.current.x - p1.x) * 0.15;
        p1.y += (mousePos.current.y - p1.y) * 0.15;
        p1.rotation = (p1.x - screenCenterX) / 40;
      } else {
        // GAMEPAD MODE (Use Controller 0)
        const gp0 = gamepads[0];
        if (gp0) {
          p1.type = 'GAMEPAD';
          const SENSITIVITY = 15;
          // Use Right Stick for Cursor usually, but let's use Axis 0/1 (Left Stick) for "Leader" convenience or stick to IR logic
          // Wii Cursor usually IR. Let's map Right Stick (Axis 2/3) for pointer to keep movement separate
          const axisX = gp0.axes[2] || 0;
          const axisY = gp0.axes[3] || 0;
          
          if (Math.abs(axisX) > 0.1) p1.x += axisX * SENSITIVITY;
          if (Math.abs(axisY) > 0.1) p1.y += axisY * SENSITIVITY;

          p1.x = Math.max(0, Math.min(window.innerWidth, p1.x));
          p1.y = Math.max(0, Math.min(window.innerHeight, p1.y));
          
          p1.clicked = gp0.buttons[0]?.pressed || gp0.buttons[7]?.pressed; // A or RT
          p1.rotation = (p1.x - screenCenterX) / 40;
        }
      }
    }

    // 2. Poll Gamepads for P2, P3, P4
    // Logic: If P1 is Gamepad (Index 0), then P2 should be Index 1, etc.
    // If P1 is Mouse, P2 is Index 0.
    
    // Check for NEW connections (LB+RB)
    for (const gp of gamepads) {
      if (!gp) continue;
      
      // Skip if this gamepad is already controlling P1
      if (p1IsGamepad && gp.index === 0) continue; 
      
      // Join Combo: Button 4 (LB) + Button 5 (RB)
      if (gp.buttons[4]?.pressed && gp.buttons[5]?.pressed) {
        const exists = cursorsRef.current.find(c => c.padIndex === gp.index);
        
        // Only add if not exists and space available
        if (!exists && cursorsRef.current.length < 4) {
           const newId = cursorsRef.current.length + 1;
           const newCursor: PlayerCursor = {
             id: newId,
             type: 'GAMEPAD',
             padIndex: gp.index,
             x: window.innerWidth / 2,
             y: window.innerHeight / 2,
             rotation: 0,
             clicked: false,
             color: PLAYER_COLORS[newId - 1],
             label: `P${newId}`
           };
           cursorsRef.current.push(newCursor);
        }
      }
    }

    // Update P2-P4 Gamepad Cursors
    cursorsRef.current.forEach(c => {
      if (c.id !== 1 && c.type === 'GAMEPAD' && c.padIndex !== undefined) {
        const gp = gamepads[c.padIndex];
        if (gp) {
          const SENSITIVITY = 15;
          const axisX = gp.axes[2] || 0; 
          const axisY = gp.axes[3] || 0;

          if (Math.abs(axisX) > 0.1) c.x += axisX * SENSITIVITY;
          if (Math.abs(axisY) > 0.1) c.y += axisY * SENSITIVITY;

          c.x = Math.max(0, Math.min(window.innerWidth, c.x));
          c.y = Math.max(0, Math.min(window.innerHeight, c.y));

          c.clicked = gp.buttons[0]?.pressed || gp.buttons[7]?.pressed;
          c.rotation = (c.x - window.innerWidth / 2) / 40;
        }
      }
    });

    setCursors([...cursorsRef.current]);
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current !== null) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, [p1IsGamepad]); // Restart loop if mode changes

  return (
    <>
      {cursors.map(c => (
        <div 
          key={c.id}
          className="pointer-events-none fixed z-[9999] top-0 left-0 mix-blend-normal will-change-transform"
          style={{ 
            transform: `translate3d(${c.x}px, ${c.y}px, 0) scale(${c.clicked ? 0.9 : 1})`,
          }}
        >
          <div className="-translate-x-1/3 -translate-y-1/6">
            <HandCursorSvg rotation={c.rotation} color={c.color} label={c.label} />
          </div>
        </div>
      ))}
    </>
  );
};

export default Cursor;
